import eruda from 'eruda';

eruda.init();

export default eruda;
